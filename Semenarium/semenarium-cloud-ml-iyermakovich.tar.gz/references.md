## Referencje

- [Serwisy AWS](https://aws.amazon.com/machine-learning/ai-services/) - https://aws.amazon.com/machine-learning/ai-services/
- [Ray](https://github.com/ray-project/ray) - https://github.com/ray-project/ray
- [Boto3 Transcribe](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/transcribe/client/start_transcription_job.html) - https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/transcribe/client/start_transcription_job.html
- [Code Guru Test](https://github.com/Ignatella/code-guru-test) - https://github.com/Ignatella/code-guru-test
- [Getting started with Amazon SageMaker](https://aws.amazon.com/sagemaker/getting-started/) - https://aws.amazon.com/sagemaker/getting-started/
- [Amazon SageMaker pricing](https://aws.amazon.com/sagemaker/pricing/) - https://aws.amazon.com/sagemaker/pricing/
- [What are Azure AI services?](https://learn.microsoft.com/en-us/azure/ai-services/what-are-ai-services) - https://learn.microsoft.com/en-us/azure/ai-services/what-are-ai-services
- [Llama 2 foundation models from Meta are now available in Amazon SageMaker JumpStart](https://aws.amazon.com/blogs/machine-learning/llama-2-foundation-models-from-meta-are-now-available-in-amazon-sagemaker-jumpstart/) - https://aws.amazon.com/blogs/machine-learning/llama-2-foundation-models-from-meta-are-now-available-in-amazon-sagemaker-jumpstart/
- [Amazon CodeWhisperer](https://aws.amazon.com/codewhisperer/?did=ft_card&trk=ft_card) - https://aws.amazon.com/codewhisperer/?did=ft_card&trk=ft_card
- [Llama 2](https://github.com/meta-llama/llama) - https://github.com/meta-llama/llama
- [AI and machine learning solutions](https://cloud.google.com/solutions/ai?hl=en) - https://cloud.google.com/solutions/ai?hl=en
- [GCP Detect Labels](https://cloud.google.com/vision/docs/labels#vision_label_detection-python) - https://cloud.google.com/vision/docs/labels#vision_label_detection-python
